select * 
from orderdetails
 where (quantityOrdered*priceEach)>10000;
