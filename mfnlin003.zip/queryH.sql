select count(*) as numEmps from employees;
