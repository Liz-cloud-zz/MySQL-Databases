select distinct city  from offices;
 