select * from offices
 where country ='UK' OR country= 'SA';
