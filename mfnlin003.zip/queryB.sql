select city , phone
	
from offices 
order by city ,phone desc
  