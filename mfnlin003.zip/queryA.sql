select *from offices;
